# ft_package

A small Python package that provides `count_in_list`, a helper function to count how many times an element appears in a list.
