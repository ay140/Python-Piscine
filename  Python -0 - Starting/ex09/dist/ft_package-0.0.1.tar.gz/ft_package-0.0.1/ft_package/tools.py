def count_in_list(lst, item):
    """
    Count how many times `item` appears in the list `lst`.
    """
    return lst.count(item)